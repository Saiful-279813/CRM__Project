
<?php $__env->startSection('employee'); ?> active mm-active <?php $__env->stopSection(); ?>
<?php $__env->startSection('commision'); ?> active <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  
  <div class="row">
      <div class="col-12">
          <div class="page-title-box d-flex align-items-center justify-content-between">
              <h4 class="mb-0 font-size-18">Commision Payment</h4>
              <div class="page-title-right">
                  <ol class="breadcrumb m-0">
                      <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                      <li class="breadcrumb-item active">Commision Payment</li>
                  </ol>
              </div>
          </div>
      </div>
  </div>
  
  <div class="row">
      <div class="col-md-2"></div>
      <div class="col-md-8">
          <?php if(Session::has('requestSend')): ?>
            <div class="alert alert-success alertsuccess" role="alert">
               <strong>Successfully!</strong> Send Your Request.
            </div>
          <?php endif; ?>

          <?php if(Session::has('error')): ?>
            <div class="alert alert-warning alerterror" role="alert">
               <strong>Opps!</strong> please try again.
            </div>
          <?php endif; ?>
      </div>
      <div class="col-md-2"></div>
  </div>
  
  <div class="row">
    <div class="col-lg-12">
        <form class="form-horizontal" method="post" action="<?php echo e(route('commision.update',$data->id)); ?>" enctype="multipart/form-data" id="customerForm">
          <?php echo csrf_field(); ?>
          <?php echo method_field('put'); ?>
          <div class="card">
            <div class="card-header custom-card-header">
                <div class="row">
                    <div class="col-md-8">
                        <h3 class="card-title card_top_title"><i class="fab fa-gg-circle"></i>Edit Commision Payment For Employee</h3>
                    </div>
                    <div class="col-md-4 text-right">
                        <a href="<?php echo e(route('commision.index')); ?>" class="btn btn-md btn-primary waves-effect card_top_button"><i class="fa fa-th"></i> Commision Payment List </a>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>

            <div class="card-body card_form">

              <div class="form-group custom_form_group row">
                  <label class="control-label col-md-4">Employee Id:<span class="req_star">*</span></label>
                  <div class="col-md-5">
                      <select class="form-control search_select" name="employee_id" id="search_select" required>
                        <option value="">Select Employee</option>
                        <?php $__currentLoopData = $employeeId; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($employee->employee_id); ?>" <?php echo e($employee->employee_id == $data->employee_id ? 'selected' : ''); ?>><?php echo e($employee->ID_Number); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                  </div>
              </div>

              <div class="form-group custom_form_group row">
                  <label class="control-label col-md-4">Commision Amount:<span class="req_star">*</span></label>
                  <div class="col-md-5">
                        <input type="text" placeholder="Amount" class="form-control" name="commision_amount" value="<?php echo e($data->commision_amount); ?>" required data-parsley-pattern="[0-9]+$" min="0" data-parsley-length="[1,7]" data-parsley-trigger="keyup">
                        <?php $__errorArgs = ['commision_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
              </div>

              <div class="form-group custom_form_group row">
                  <label class="control-label col-md-4">Commision Reason:<span class="req_star">*</span></label>
                  <div class="col-md-5">

                        <textarea class="form-control" name="remarks" rows="4" cols="80" required placeholder="Commision Reason..."><?php echo e($data->remarks); ?></textarea>

                        <?php $__errorArgs = ['remarks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
              </div>

            </div>

            <div class="card-footer card_footer_button text-center">
                <button type="submit" class="btn btn-primary waves-effect">UPDATE</button>
            </div>
          </div>
          
        </form>
    </div>
  </div>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\SERVER\htdocs\Office\CRM__Project\resources\views/admin/commision/edit.blade.php ENDPATH**/ ?>