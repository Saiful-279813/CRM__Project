<div class="vertical-menu">
    <div data-simplebar class="h-100">
        <div id="sidebar-menu">
            <ul class="metismenu list-unstyled" id="side-menu">
                <li><a href="<?php echo e(route('admin.dashboard')); ?>" class="waves-effect"><i class="bx bx-home-circle"></i><span>Dashboard</span></a></li>

                <li class="<?php echo $__env->yieldContent('admin'); ?>"><a href="#" class="waves-effect"><i class="bx bx-cog"></i><span>Administrator</span></a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a class="<?php echo $__env->yieldContent('userChild'); ?>" href="<?php echo e(route('users.index')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Users </a></li>
                        
                        <li><a class="<?php echo $__env->yieldContent('role'); ?>" href="<?php echo e(route('roles.index')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Role </a></li>
                        
                        <li><a class="<?php echo $__env->yieldContent('blood'); ?>" href="<?php echo e(route('blood.index')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Blood Group </a></li>
                        
                        <li><a class="<?php echo $__env->yieldContent('department'); ?>" href="<?php echo e(route('department.index')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Department </a></li>
                        
                        <li><a class="<?php echo $__env->yieldContent('designation'); ?>" href="<?php echo e(route('designation.index')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Designation </a></li>
                        
                        <li><a class="<?php echo $__env->yieldContent('employee-type'); ?>" href="<?php echo e(route('employee-type.index')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Employee Type </a></li>
                        
                        <li><a class="<?php echo $__env->yieldContent('pending-income'); ?>" href="<?php echo e(route('pending-income')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Pending Income </a></li>

                        <li><a class="<?php echo $__env->yieldContent('pending-expense'); ?>" href="<?php echo e(route('pending-expense')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Pending Expense </a></li>

                        <li><a class="<?php echo $__env->yieldContent('pending-advance-pay'); ?>" href="<?php echo e(route('pending-advance-pay')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Pending Advance Payment </a></li>

                        <li><a class="<?php echo $__env->yieldContent('pending-commision'); ?>" href="<?php echo e(route('pending-commision')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Pending Commision </a></li>

                        <li><a class="<?php echo $__env->yieldContent('employee-approve'); ?>" href="<?php echo e(route('employee-approve')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Employee Approve </a></li>
                        
                    </ul>
                </li>
                
                <li class="<?php echo $__env->yieldContent('accounts'); ?>"><a href="#" class="waves-effect"><i class="bx bx-package"></i><span>Finance & Accounting</span></a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a class="<?php echo $__env->yieldContent('balancesheet'); ?>" href="#"> <i class="fas fa-arrow-right sm child_i"></i> Balance Sheet </a></li>
                        <li><a class="<?php echo $__env->yieldContent('summary'); ?>" href="<?php echo e(route('income-expense.summary')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Summary </a></li>
                        <li><a class="<?php echo $__env->yieldContent('income'); ?>" href="<?php echo e(route('income.index')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Daily Income </a></li>
                        <li><a class="<?php echo $__env->yieldContent('expense'); ?>" href="<?php echo e(route('expense.index')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Daily Expense </a></li>
                        <li><a class="<?php echo $__env->yieldContent('incomeCategory'); ?>" href="<?php echo e(route('income-category.index')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Income Category </a></li>
                        <li><a class="<?php echo $__env->yieldContent('expenseCategory'); ?>" href="<?php echo e(route('expense-category.index')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Expense Category </a></li>
                        <li><a class="<?php echo $__env->yieldContent('cashflow'); ?>" href="#"> <i class="fas fa-arrow-right sm child_i"></i> Cash Flow </a></li>
                        <li><a class="<?php echo $__env->yieldContent('payment'); ?>" href="#"> <i class="fas fa-arrow-right sm child_i"></i> Payment </a></li>
                        
                    </ul>
                </li>
                
                <li class="<?php echo $__env->yieldContent('customer'); ?>"><a href="#" class="waves-effect"><i class='bx bx-street-view'></i><span>Customers</span></a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a class="<?php echo $__env->yieldContent('addCustomer'); ?>" href="<?php echo e(route('customers.create')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Add Customer </a></li>
                        
                        <li><a class="<?php echo $__env->yieldContent('customerList'); ?>" href="<?php echo e(route('customers.index')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Customer List </a></li>
                        
                        <li><a class="<?php echo $__env->yieldContent('customerTransaction'); ?>" href="<?php echo e(route('customer-trnasaction.index')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Customer Transaction </a></li>
                    </ul>
                </li>

                <li class="<?php echo $__env->yieldContent('employee'); ?>"><a href="#" class="waves-effect"><i class="bx bx-happy-alt"></i><span>Employee</span></a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a class="<?php echo $__env->yieldContent('addEmployee'); ?>" href="<?php echo e(route('employee.create')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Add New Employee </a></li>
                        <li><a class="<?php echo $__env->yieldContent('listEmployee'); ?>" href="<?php echo e(route('employee.index')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Employee List </a></li>
                        <li><a class="<?php echo $__env->yieldContent('salary'); ?>" href="<?php echo e(route('salary.index')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Employee Salary </a></li>
                        
                        <li><a class="<?php echo $__env->yieldContent('advancePay'); ?>" href="<?php echo e(route('employee-advance-pay')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Advance Pay </a></li>
                        
                        <li><a class="<?php echo $__env->yieldContent('commision'); ?>" href="<?php echo e(route('commision.create')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Commision </a></li>
                    </ul>
                </li>
                
                <li class="<?php echo $__env->yieldContent('work'); ?>"><a href="#" class="waves-effect"><i class='bx bx-briefcase'></i><span>Work History</span></a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a class="<?php echo $__env->yieldContent('monthWorkHistory'); ?>" href="<?php echo e(route('month-work.index')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Month Work </a></li>
                    </ul>
                </li>
                
                <li class="<?php echo $__env->yieldContent('salary'); ?>"><a href="#" class="waves-effect"><i class='bx bxs-wallet-alt'></i><span>Salary System</span></a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a class="<?php echo $__env->yieldContent('salaryGenerate'); ?>" href="<?php echo e(route('salary-generate')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Salary Generat </a></li>
                        <li><a class="<?php echo $__env->yieldContent('salaryReport'); ?>" href="<?php echo e(route('salary-report')); ?>"> <i class="fas fa-arrow-right sm child_i"></i> Salary Report </a></li>
                    </ul>
                </li>


                



                <li><a href="<?php echo e(url('dashboard/recycle')); ?>" class="waves-effect"><i class="bx bx-trash"></i><span>Recycle</span></a></li>
                <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();" class="waves-effect"><i class="bx bx-power-off"></i><span>Logout</span></a></li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\SERVER\htdocs\Office\CRM__Project\resources\views/layouts/include/menu.blade.php ENDPATH**/ ?>