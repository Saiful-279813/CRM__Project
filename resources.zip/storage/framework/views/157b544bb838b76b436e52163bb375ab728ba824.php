
<?php $__env->startSection('admin'); ?> active mm-active <?php $__env->stopSection(); ?>
<?php $__env->startSection('userChild'); ?> active <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  
  <div class="row">
      <div class="col-12">
          <div class="page-title-box d-flex align-items-center justify-content-between">
              <h4 class="mb-0 font-size-18">Management User</h4>
              <div class="page-title-right">
                  <ol class="breadcrumb m-0">
                      <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                      <li class="breadcrumb-item active">Management User</li>
                  </ol>
              </div>
          </div>
      </div>
  </div>
  
  <div class="row">
      <div class="col-md-2"></div>
      <div class="col-md-8">
          <?php if(Session::has('store_success')): ?>
            <div class="alert alert-success alertsuccess" role="alert">
               <strong>Successfully!</strong> Create New User.
            </div>
          <?php endif; ?>

          <?php if(Session::has('error')): ?>
            <div class="alert alert-warning alerterror" role="alert">
               <strong>Opps!</strong> please try again.
            </div>
          <?php endif; ?>
      </div>
      <div class="col-md-2"></div>
  </div>
  
  <div class="row">
    <div class="col-lg-12">
        <form class="form-horizontal" method="post" action="<?php echo e(route('users.store')); ?>" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="card">
              <div class="card-header custom-card-header">
                  <div class="row">
                      <div class="col-md-8">
                          <h3 class="card-title card_top_title"><i class="fab fa-gg-circle"></i> Create New User</h3>
                      </div>
                      <div class="col-md-4 text-right">
                          <a href="<?php echo e(route('users.index')); ?>" class="btn btn-md btn-primary waves-effect card_top_button"><i class="fa fa-th"></i> All User List </a>
                      </div>
                      <div class="clearfix"></div>
                  </div>
              </div>
              <div class="card-body card_form">
                <div class="form-group row custom_form_group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                    <label class="col-sm-3 control-label">Name:<span class="req_star">*</span></label>
                    <div class="col-sm-7">
                      <input type="text" placeholder="Name" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required>
                      <?php if($errors->has('name')): ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('name')); ?></strong>
                          </span>
                      <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row custom_form_group<?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
                    <label class="col-sm-3 control-label">Phone:<span class="req_star">*</span></label>
                    <div class="col-sm-7">
                      <input type="text" placeholder="Phone" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>" required>
                      <?php if($errors->has('phone')): ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('phone')); ?></strong>
                          </span>
                      <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row custom_form_group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                    <label class="col-sm-3 control-label">Email:<span class="req_star">*</span></label>
                    <div class="col-sm-7">
                      <input type="email" placeholder="Email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>
                      <?php if($errors->has('email')): ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('email')); ?></strong>
                          </span>
                      <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row custom_form_group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                    <label class="col-sm-3 control-label">Password:<span class="req_star">*</span></label>
                    <div class="col-sm-7">
                      <input type="password" placeholder="Password" class="form-control" name="password" required>
                      <?php if($errors->has('password')): ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('password')); ?></strong>
                          </span>
                      <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row custom_form_group<?php echo e($errors->has('confirm-password') ? ' has-error' : ''); ?>">
                    <label class="col-sm-3 control-label">Confirm Password:<span class="req_star">*</span></label>
                    <div class="col-sm-7">
                      <input type="password" placeholder="Password" class="form-control" name="confirm-password" required>
                      <?php if($errors->has('confirm-password')): ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('confirm-password')); ?></strong>
                          </span>
                      <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row custom_form_group<?php echo e($errors->has('roles') ? ' has-error' : ''); ?>">
                    <label class="col-sm-3 control-label">Role:<span class="req_star">*</span></label>
                    <div class="col-sm-7">
                      <select class="form-control" name="roles" required>
                        <option value="">Select Role</option>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($role); ?>"><?php echo e($role); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      <?php if($errors->has('roles')): ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('roles')); ?></strong>
                          </span>
                      <?php endif; ?>
                    </div>
                </div>
              </div>
              <div class="card-footer card_footer_button text-center">
                  <button type="submit" class="btn btn-primary waves-effect">SAVE</button>
              </div>
          </div>
        </form>
    </div>
  </div>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\SERVER\htdocs\Office\CRM__Project\resources\views/admin/users/create.blade.php ENDPATH**/ ?>