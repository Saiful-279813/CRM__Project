
<?php $__env->startSection('work'); ?> active mm-active <?php $__env->stopSection(); ?>
<?php $__env->startSection('monthWorkHistory'); ?> active <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  
  <div class="row">
      <div class="col-12">
          <div class="page-title-box d-flex align-items-center justify-content-between">
              <h4 class="mb-0 font-size-18">Month Work</h4>
              <div class="page-title-right">
                  <ol class="breadcrumb m-0">
                      <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                      <li class="breadcrumb-item active">Month Work</li>
                  </ol>
              </div>
          </div>
      </div>
  </div>
  
  <div class="row">
      <div class="col-md-2"></div>
      <div class="col-md-8">
          <?php if(Session::has('success_update')): ?>
            <div class="alert alert-success alertsuccess" role="alert">
               <strong>Successfully!</strong> Update Employee Month Work Information.
            </div>
          <?php endif; ?>

          <?php if(Session::has('error')): ?>
            <div class="alert alert-warning alerterror" role="alert">
               <strong>Opps!</strong> please try again.
            </div>
          <?php endif; ?>
      </div>
      <div class="col-md-2"></div>
  </div>
  
  <div class="row">
    <div class="col-lg-12">
        <form class="form-horizontal" method="post" action="<?php echo e(route('month-work.update',$data->month_work_id)); ?>" enctype="multipart/form-data" id="customerForm">
          <?php echo csrf_field(); ?>
          <?php echo method_field('put'); ?>
          <div class="card">
            <div class="card-header custom-card-header">
                <div class="row">
                    <div class="col-md-8">
                        <h3 class="card-title card_top_title"><i class="fab fa-gg-circle"></i> Added Month Work Information</h3>
                    </div>
                    <div class="col-md-4 text-right">
                        <a href="<?php echo e(route('month-work.index')); ?>" class="btn btn-md btn-primary waves-effect card_top_button"><i class="fa fa-th mr-2"></i>All Month Work History</a>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>

            <div class="card-body card_form">
                <div class="form-group custom_form_group row mb-3">
                    <label class="col-sm-4 col-form-label col_form_label">Employee Name:<span class="req_star">*</span></label>
                    <div class="col-sm-5">
                        <select class="form-control" name="employee_id" id="search_select2" required>
                          <option value="">----Select Employee----</option>
                          <?php $__currentLoopData = $employeeId; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value->employee_id); ?>" <?php echo e($value->employee_id == $data->employee_id ? 'selected' : ''); ?>><?php echo e($value->employee_name); ?>(<?php echo e($value->ID_Number); ?>)</option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['employee_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="form-group custom_form_group row mb-3">
                    <label class="col-sm-4 col-form-label col_form_label">Month:<span class="req_star">*</span></label>
                    <div class="col-sm-5">
                      <select class="form-control" name="month_name" required id="search_select3">
                        <option value="">----Select Month----</option>
                        <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($month->month_id); ?>" <?php echo e($month->month_id == $data->month_id ? 'selected' : ''); ?>><?php echo e($month->month_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                </div>

                <div class="form-group custom_form_group row mb-3">
                    <label class="col-sm-4 col-form-label col_form_label">Year:<span class="req_star">*</span></label>
                    <div class="col-sm-5">
                      <select class="form-control" name="year" required id="search_select4">
                        <option value="">----Select Year----</option>
                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($value); ?>" <?php echo e($value == $data->year ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                </div>

                <div class="form-group custom_form_group row mb-3">
                    <label class="col-sm-4 col-form-label col_form_label">Overtime Amount:<span class="req_star">*</span></label>
                    <div class="col-sm-5">
                        <input type="text" placeholder="Amount..." class="form-control" name="overtime_amount" value="<?php echo e($data->overtime_amount); ?>" required data-parsley-pattern="[0-9]+$" data-parsley-length="[0,15]" data-parsley-trigger="keyup">
                        <?php $__errorArgs = ['overtime_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="form-group custom_form_group row mb-3">
                    <label class="col-sm-4 col-form-label col_form_label">Deduction Amount:<span class="req_star">*</span></label>
                    <div class="col-sm-5">
                        <input type="text" placeholder="Amount..." class="form-control" name="deduction_amount" value="<?php echo e($data->deduction_amount); ?>" required data-parsley-pattern="[0-9]+$" data-parsley-length="[0,15]" data-parsley-trigger="keyup">
                        <?php $__errorArgs = ['deduction_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="form-group custom_form_group row mb-3">
                    <label class="col-sm-4 col-form-label col_form_label">Work Days:<span class="req_star">*</span></label>
                    <div class="col-sm-5">
                        <input type="text" placeholder="Work Days" class="form-control" name="total_work_day" value="<?php echo e($data->total_work_day); ?>" required data-parsley-pattern="[0-9]+$" data-parsley-max="30" data-parsley-trigger="keyup">
                        <?php $__errorArgs = ['total_work_day'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                
            </div>
            <div class="card-footer card_footer_button text-center">
                <button type="submit" class="btn btn-primary waves-effect">UPDATE</button>
            </div>
          </div>
          
        </form>
    </div>
  </div>
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
      /* ================ do work ================ */
      $(document).ready(function() {
          $('#customerForm').parsley();
      });
      /* ================ do work ================ */
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\SERVER\htdocs\Office\CRM__Project\resources\views/admin/month_work/edit.blade.php ENDPATH**/ ?>